/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.kasirminimarket;

/**
 *
 * @author lenovo
 */
public class KasirMinimarket {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
